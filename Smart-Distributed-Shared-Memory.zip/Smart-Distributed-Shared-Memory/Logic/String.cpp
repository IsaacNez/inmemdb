/*
 * String.cpp
 *
 *  Created on: Sep 15, 2015
 *      Author: jairo-mm
 */

#include "String.h"
#include <new>

/**
 * @brief
 */
String::String() {
	// TODO Auto-generated constructor stub
	_data = 0;
}

/**
 * @brief
 */
String::~String() {
	// TODO Auto-generated destructor stub
}

/**
 * @brief
 * @param pstring
 * @return
 */
String& String::operator =(const String& pstring)
{
	//TODO usar el d_pointer para hacer el seteo del dato en la memoria del nodo
	pthread_mutex_lock(&this->mutex);
	setData(pstring.getData());
	pthread_mutex_lock(&this->mutex);
	return *this;
}

/**
 * @brief
 * @param pstring
 * @return
 */
String& String::operator =(char* pstring)
{
	//TODO usar el d_pointer para hacer el seteo del dato en la memoria del nodo
	pthread_mutex_lock(&this->mutex);
	setData(pstring);
	pthread_mutex_lock(&this->mutex);
	return *this;
}

void* String::operator new(size_t size)
{
	return ::operator new(size);
}
