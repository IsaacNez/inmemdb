/*
 * dObject.cpp
 *
 *  Created on: Sep 3, 2015
 *      Author: jairo-mm
 */

#include "dObject.h"

bool dObject::_usageFlag;

/**
 * Constructor
 * setea los valores iniciales del tipo de dato, id y bandera de uso
 * @param pdata_type
 * @param pId
 */
dObject::dObject() {
	// TODO Auto-generated constructor stub
	_usageFlag = false;
	_data_type = 0;
	pthread_t threadID;
	//pthread_create(&threadID, NULL, init, NULL);
	//pthread_join(threadID, NULL);
}

/**
 * Destructor
 */
dObject::~dObject() {
	// TODO Auto-generated destructor stub
	//pthread_exit(NULL);
}

/**
 * Se setea el tipo de dato al parametro pType
 * @param pType
 */
void dObject::setObjectType(char* pType)
{
	_data_type = pType;
}

/**
 * Se setea la bandera de uso al parametro entrante
 * @param pusageFlag
 */
void dObject::setObjectUsageFlag(bool pusageFlag)
{
	_usageFlag = pusageFlag;
}

/**
 * Retorna el tipo de dato del objeto
 * @return _data_type
 */
char* dObject::getObjectType()
{
	return _data_type;
}

/**
 * Retorna la bandera de uso del objeto
 * @return _usageFlag
 */
bool dObject::getObjectUsageFlag()
{
	return _usageFlag;
}


void* dObject::init(void* pdata)
{
	//TODO nothing ;)
}
