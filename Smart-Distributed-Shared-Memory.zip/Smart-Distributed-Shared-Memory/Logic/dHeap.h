/*
 * dHeap.h
 *
 *  Created on: 7 de set. de 2015
 *      Author: isaac
 */

#ifndef DHEAP_H_
#define DHEAP_H_
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <sstream>
#include <pthread.h>
#include <cstdlib>

#include "Constants.h"
#include "../DataStructure/LinkedList.h"
#include "../DataStructure/Node.h"
#include "../DataComunication/Server.h"
#include "../DataComunication/Cliente.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/prettywriter.h"
#include "rapidjson/reader.h"
#include "rapidjson/writer.h"
#include "rapidjson/document.h"
#include "dpointersizetype.h"
#include "tinyxml2.h"

using namespace std;
using namespace tinyxml2;
using namespace rapidjson;


struct NodoSDSMNode{
	int ID;
	Cliente* Comunication;
	LinkedList<d_pointer_size_type*> _DatosInMemory;
};


class dHeap {
private:
	bool _FlagSaving;
	dHeap(const char* pFile);
	static bool instanceFlag;
	bool _Done;
	static dHeap* _DHeap;
	int _Contador;
	char* _Address;
	char* _Data;
	LinkedList<NodoSDSMNode*> *_InfoSocket;
	LinkedList<d_pointer_size_type*>* _Direcciones;
	pthread_mutex_t flag;
	LinkedList<d_pointer_size_type*>* _ListDPointers;

	Node<void*>*_SearchInMemory(string pPointer);
	void ReadConfigFile(const char* URL);
	int ChoosePort();


public:
	int _PrivateMemory;
	d_pointer_size_type* SearchInMemory(d_pointer_size_type* pPointer);
	static dHeap* getInstance();
	d_pointer_size_type* dMalloc(int, char*);
	void dFree(d_pointer_size_type* pPointer);
	char* dGet(d_pointer_size_type* pPointer);
	void dSet(d_pointer_size_type* pPointer, char* pData);
	void dStatus();
	char* dMessage(char* message);
	LinkedList<d_pointer_size_type*>* getListDPointers();
	virtual ~dHeap();
};
#endif /* LOGIC_DHEAP_H_ */




