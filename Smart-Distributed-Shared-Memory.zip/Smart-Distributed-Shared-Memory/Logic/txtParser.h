/*
 * txtParcer.h
 *
 *  Created on: 27 de set. de 2015
 *      Author: jeja
 */

#ifndef LOGIC_TXTPARSER_H_
#define LOGIC_TXTPARSER_H_

#include <string>
#include "../DataStructure/LinkedList.h"
#include <iostream>
#include <fstream>


using namespace std;

class txtParser {
public:
	txtParser(string pFile);
	virtual ~txtParser();
	LinkedList<string>* _getWordList();

private:
	string _File;
	string _Line;
	LinkedList<string>* _WordList;
	void start();
	void divideWords();
};

#endif /* LOGIC_TXTPARSER_H_ */
