/*
 * dString.cpp
 *
 *  Created on: Oct 6, 2015
 *      Author: jairo-mm
 */

#include "dString.h"
#include "dHeap.h"
#include "Constants.h"
#include <iostream>
#include <stdlib.h>
#include <new>

d_pointer_size_type* dString::pointer = 0;

/**
 * @brief
 */
dString::dString() {
	if(Constants::DEBBUG_FLAG)
		std::cout << "dString  "<< Constants::CREATING_A_NEW_OBJECT << std::endl;
	//pointer->dPointer_setData_ToHeap((void*)this);

}

/**
 * @brief
 */
dString::~dString() {
	// TODO Auto-generated destructor stub
	//pointer->~d_pointer_size_type();
	dHeap::getInstance()->dFree(pointer);
}

/**
 * @brief
 * @param pint
 * @return
 */
void dString::operator =(const dString& pint)
{
	if(Constants::DEBBUG_FLAG)
		std::cout << Constants::MAKING_AN_EQUALIZATION_OF_OBJECTS << std::endl;
	setDataWithPointer((char*)pint.getData());
	//setData(pint.getData());

}

/**
 * @brief
 * @param pint
 * @return
 */
void dString::operator =(const char* pint)
{
	if(Constants::DEBBUG_FLAG)
		std::cout << Constants::MAKING_AN_ASSIGNMENT_OF_OBJECTS << std::endl;

	//pthread_mutex_lock(&this->mutex);
	setDataWithPointer((char*)pint);
	//pthread_mutex_unlock(&this->mutex);
	//setData(pint);
}

/**
 * @brief
 * @param pint
 * @return
 */
bool dString::operator ==(const dString& pint)
{
	if(Constants::DEBBUG_FLAG)
		std::cout << Constants::MAKING_A_COMPARISON_OF_OBJECTS << std::endl;
	//pthread_mutex_lock(&this->mutex);
	if(this->_data == pint.getData())
		//pthread_mutex_unlock(&this->mutex);
		return true;
	//pthread_mutex_unlock(&this->mutex);
	return false;
}

/**
 * @brief
 * @param pint
 * @return
 */
bool dString::operator ==(const char* pint)
{
	if(Constants::DEBBUG_FLAG)
		std::cout << Constants::MAKING_A_COMPARISON_OF_OBJECTS << std::endl;
	//pthread_mutex_lock(&this->mutex);
	if(this->_data == pint)
		//pthread_mutex_unlock(&this->mutex);
		return true;
	return false;
}


/**
 * @brief
 * @param size
 * @return
 */
void* dString::operator new(size_t size)
{
	pointer = (dHeap::getInstance()->dMalloc(size, Constants::INT));
	//TODO something about the memory in the SDSMMN
	return ::operator new(size);
}

void* dString::operator new[](size_t size)
{
	pointer = (dHeap::getInstance()->dMalloc(size, Constants::INT));
	//TODO something about the memory in the SDSMMN
	return ::operator new(size);
}

dString& dString::operator [](int index)
{
	cout << "estoy utilizando [] " << endl;
	dString* tmp = (dString*)pointer->dPointer_getData_fromHeap();
	return *(tmp + index);
}

void dString::setDataWithPointer(char* pdata)
{
	cout << Constants::MAKING_GET_AND_SET_WITH_FROM_OBJECT << endl;
	dString* tmp = (dString*)pointer->dPointer_getData_fromHeap();
	cout << "Hola muchachos" << endl;
	tmp->setData(pdata);
	cout << "SIIII" << endl;
	pointer->dPointer_setData_ToHeap((void*)tmp);
}

