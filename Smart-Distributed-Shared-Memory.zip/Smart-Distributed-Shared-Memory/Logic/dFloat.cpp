/*
 * dFloat.cpp
 *
 *  Created on: Sep 15, 2015
 *      Author: jairo-mm
 */

#include "dFloat.h"
#include <new>

/**
 * @brief
 */
dFloat::dFloat() {
	// TODO Auto-generated constructor stub
	_data = 0;
}

/**
 * @brief
 */
dFloat::~dFloat() {
	// TODO Auto-generated destructor stub
}

/**
 * @brief
 * @param pfloat
 * @return
 */
dFloat& dFloat::operator =(const dFloat& pfloat)
{
	pthread_mutex_lock(&this->mutex);
	setData(pfloat.getData());
	pthread_mutex_unlock(&this->mutex);
	return *this;
}

/**
 * @brief
 * @param pfloat
 * @return
 */
dFloat& dFloat::operator =(float pfloat)
{
	pthread_mutex_lock(&this->mutex);
	setData(pfloat);
	pthread_mutex_unlock(&this->mutex);
	return *this;
}

/**
 * @brief
 * @param size
 */
void* dFloat::operator new(size_t size)
{

	//TODO something about the memory in the SDSMMN

	return ::operator new(size);
}
