/*
 * Constants.h
 *
 *  Created on: Sep 30, 2015
 *      Author: jairo-mm
 */

#ifndef LOGIC_CONSTANTS_H_
#define LOGIC_CONSTANTS_H_

#include <string.h>

class Constants {
public:
	Constants();
	virtual ~Constants();
	static bool DEBBUG_FLAG;
	static char* MAKING_A_COMPARISON_OF_OBJECTS;
	static char* MAKING_AN_ASSIGNMENT_OF_OBJECTS;
	static char* MAKING_AN_EQUALIZATION_OF_OBJECTS;
	static char* CREATING_A_NEW_OBJECT;
	static char* MAKING_A_COMPARISON_OF_POINTERS;
	static char* MAKING_AN_ASSIGNMENT_OF_POINTERS;
	static char* MAKING_AN_EQUALIZATION_OF_POINTERS;
	static char* MEMORY_HAS_BEEN_RELEASE;
	static char* WRONG_MEMORY_SPACE;
	static char* SAVED_DATA;
	static char* PROJECT;
	static char* CLIENT;
	static char* IP;
	static char* PORT;
	static char* PROTOCOL;
	static char* D_CALLOC;
	static char* D_FREE;
	static char* P_SIZE;
	static char* ADDR;
	static char* D_STATUS;
	static char* ADDRESS;
	static char* TYPE;
	static char* XML_ADDRESS;
	static char* DATO;
	static char* D_GET;
	static char* D_SET;
	static char* DBOOL;
	static char* DFLOAT;
	static char* DLONG;
	static char* DDOUBLE;
	static char* DINT;
	static char* DCHAR;
	static char* DSTRING;
	static char* MEMORY_FREED;
	static char* INCORRECT_MEMORY_ACCESS;
	static char* DATA_SAVED;
	static char* NOT_ACCESS_TO_MEMORY_SPACE;
	static char* MAKING_GET_AND_SET_WITH_FROM_OBJECT;
	static char* INT;
	static char* MAKING_SET_FROM_POINTER_TO_HEAP;
	static char* MAKING_GET_FROM_POINTER_TO_HEAP;
	static char* SENDING_DATA_FROM_D_CALLOC;
	static char* SENDING_DATA_FROM_D_SET;

};

#endif /* LOGIC_CONSTANTS_H_ */
