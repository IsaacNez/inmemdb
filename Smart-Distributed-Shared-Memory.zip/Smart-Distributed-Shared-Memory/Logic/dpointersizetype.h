/*
 * Dpointersizetype.h
 *
 *  Created on: 7 de set. de 2015
 *      Author: jeja
 */

#ifndef LOGIC_DPOINTERSIZETYPE_H_
#define LOGIC_DPOINTERSIZETYPE_H_

#include "dObject.h"
#include <iostream>
#include <stdint.h>
#include <string.h>
#include <string>

using namespace std;

/**
 * @brief la clase d_pointer_size_type es una abstracción de un puntero
 */


class d_pointer_size_type {
public:
	dObject& operator *();
	d_pointer_size_type operator = (d_pointer_size_type);
	d_pointer_size_type operator = (dObject);
	bool operator == (d_pointer_size_type&);
	d_pointer_size_type& operator ++ ();
	d_pointer_size_type& operator -- ();
	d_pointer_size_type();
	virtual ~d_pointer_size_type();
	void setInicialID();
	void print();
	void setID(long long int pID);
	void setType(char pType);
	void setSize(long long int pSize);
	void setPointer(char* pPointer);
	void setLocation(int pLocation);
	void setReference(int pIncrease);

	long long int getID();
	char getType();
	long long int getSize();
	string getPointer();
	int getLocation();
	int getReference();

	void* dPointer_getData_fromHeap();
	void dPointer_setData_ToHeap(void* pdata);

private:
	long long int _ID; /** atributo que hace referencia al iD representativo del puntero */
	string _Pointer;/** atributo que almacena la dirección de memoria donde ha sido almacenada la memoria */
	char _Type; /** atributo que representa el tipo del puntero, Ejemplo 0 -> dInt, 1 -> char */
	int _Reference; /** atributo que indica el conteo de referencias hacia este objeto */
	int _Location;
protected:
	static long long int _Size; /** atributo que identifica el tamaño de memoria que se quiere pedir, o se pidió */
};


#endif /* LOGIC_DPOINTERSIZETYPE_H_ */
