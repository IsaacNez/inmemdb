/*
 * DGarbageCollector.cpp
 *
 *  Created on: 9 de set. de 2015
 *      Author: jeja
 */

#include "dGarbageCollector.h"

dGarbageCollector::dGarbageCollector() {
	_Frequency = 5000;// seconds of the sleep for the cycle
}

void dGarbageCollector::run(){
	while(true){
		_TmpList = dHeap::getInstance()->getListDPointers();
		for(int i = 0; i < _TmpList->getLen(); i++){
			if (_TmpList->getDatabyIndex(i)->getReference() == 0)
				dHeap::getInstance()->dFree(_TmpList->getDatabyIndex(i));

		}
		sleep(_Frequency);
	}
}

dGarbageCollector::~dGarbageCollector() {
	// TODO Auto-generated destructor stub
}

