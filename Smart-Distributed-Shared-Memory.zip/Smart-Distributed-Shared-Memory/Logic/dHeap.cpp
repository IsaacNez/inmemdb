#include "dHeap.h"

dHeap::dHeap(const char* pFile)
{
	_Contador = 0;
	_FlagSaving = false;
	_Done = true;
	_InfoSocket = new LinkedList<NodoSDSMNode*>();
	_ListDPointers = new LinkedList<d_pointer_size_type*>();
	ReadConfigFile(pFile);
	_PrivateMemory = 0;
}
bool dHeap::instanceFlag = false;

dHeap* dHeap::_DHeap = NULL;

dHeap* dHeap::getInstance(){
	if (!instanceFlag)
	{
		_DHeap = new dHeap("XMLTest.xml");
		instanceFlag = true;
		return _DHeap;
	}else{
		return _DHeap;
	}
}

LinkedList<d_pointer_size_type*>* dHeap::getListDPointers(){
	return this->_ListDPointers;
}

void dHeap::ReadConfigFile(const char* URL){
	try{
	        XMLDocument doc;
	        doc.LoadFile(URL);
	        XMLElement* project = doc.FirstChildElement("project");
	        XMLElement* nodo = project->FirstChildElement("Cliente");
	        while(nodo != 0)
	        {
	        	XMLElement* nodo2 = nodo->FirstChildElement("IP");
	        	XMLElement* nodo3 = nodo2->NextSiblingElement("Port");
	        	Cliente* Puerto = new Cliente(atoi(nodo3->GetText()), (char*)nodo2->GetText());
				NodoSDSMNode *data = new NodoSDSMNode();
				data->Comunication = Puerto;
				_InfoSocket->insertData(data);
	        	nodo = nodo->NextSiblingElement("Cliente");
	        }



	    }catch (exception& e)
	    {
	    }
}

int dHeap::ChoosePort(){
	int posicion = rand()%(_InfoSocket->getLen());
	cout << posicion << endl;
	return posicion;
}

d_pointer_size_type* dHeap::dMalloc(int pSize, char* pType){
	_FlagSaving = true;
	d_pointer_size_type *pointer = new d_pointer_size_type();

	pointer->setType(*(pType));
	pointer->setSize(pSize);
	pointer->setID(_Contador);

	StringBuffer s;
	Writer<StringBuffer> writer(s);
	writer.StartObject();
	writer.String("protocol");
	writer.String("d_calloc");
	writer.String("pSize");
	writer.Int(pSize);
	writer.EndObject();
	if(_FlagSaving)
		cout << "Se reserva memoria" << endl;

	_Contador++;
	int posicion = ChoosePort();
	_InfoSocket->getDatabyIndex(posicion)->ID = posicion;
	char* m;
	m= _InfoSocket->getDatabyIndex(posicion)->Comunication->Conectar((char*)s.GetString());
	cout << "!!!!!!!!!!!!!!!!" << m << endl;
	pointer->setPointer(m);
	pointer->setLocation(posicion);
	_InfoSocket->getDatabyIndex(posicion)->_DatosInMemory.insertData(pointer);
	_ListDPointers->insertData(pointer);
	cout << "Este es el mensaje que envía" << s.GetString() << endl;
	return pointer;
}

void dHeap::dSet(d_pointer_size_type* pPointer, char* pData){
	//cout << "haciendo dset from heap con dato " << pData << endl;
	d_pointer_size_type* puntero = SearchInMemory(pPointer);
	//cout << "haciendo dset from heap con dato 1 " << puntero->getPointer() << endl;
	StringBuffer s;
	Writer<StringBuffer> writer(s);
	writer.StartObject();
	writer.String("protocol");
	writer.String("d_set");
	writer.String("pSize");
	writer.Int(puntero->getSize());
	writer.String("addr");
	writer.String(puntero->getPointer().c_str());
	writer.String("pDato");
	writer.String(pData);
	writer.EndObject();
	//cout << "mensaje del set " <<s.GetString() << endl;
	_InfoSocket->getDatabyIndex(puntero->getLocation())->Comunication->Conectar((char*)s.GetString());
}
 void dHeap::dFree(d_pointer_size_type* pPointer){
	 d_pointer_size_type* puntero = SearchInMemory(pPointer);
	 StringBuffer s;
	 Writer<StringBuffer> writer(s);
	 writer.StartObject();
	 writer.String("protocol");
	 writer.String("d_free");
	 writer.String("addr");
	 writer.String(puntero->getPointer().c_str());
	 writer.String("pSize");
	 writer.Int(puntero->getSize());
	 writer.EndObject();
	// cout << "Mensaje del dFree" << s.GetString() << endl;
	 _InfoSocket->getDatabyIndex(puntero->getLocation())->Comunication->Conectar((char*)s.GetString());
	 _ListDPointers->deleteData(puntero);
	 _InfoSocket->getDatabyIndex(puntero->getLocation())->_DatosInMemory.deleteData(puntero);
	 delete puntero;

 }

 char* dHeap::dGet(d_pointer_size_type* pPointer){
	 d_pointer_size_type* puntero = SearchInMemory(pPointer);
	 StringBuffer s;
	 Writer<StringBuffer> writer(s);
	 writer.StartObject();
	 writer.String("protocol");
	 writer.String("d_get");
	 writer.String("addr");
	 writer.String(puntero->getPointer().c_str());
	 writer.EndObject();
	 char* data = _InfoSocket->getDatabyIndex(puntero->getLocation())->Comunication->Conectar((char*)s.GetString());
	 return data;

 }

d_pointer_size_type* dHeap::SearchInMemory(d_pointer_size_type* pPointer){
	int position = pPointer->getLocation();
	Node<d_pointer_size_type*> *tmp = _InfoSocket->getDatabyIndex(position)->_DatosInMemory.getHead();
	if(tmp == NULL)
		return NULL;
	while(tmp != NULL){
		if (tmp->getData()->getID() == pPointer->getID())
			break;
		else
			tmp = tmp->getNext();
	}
	return tmp->getData();
}

/**char* dHeap::dMessage(char* message){
	 Document doc;
	 cout << message << endl;
	 doc.ParseInsitu((char*)message);
	 cout << "hola1 " << doc.HasParseError() <<  endl;
	 if (doc.IsObject()){
		 if(doc.HasMember("protocol")){
			 string operation;
			 if (doc["protocol"].IsString()){
				 operation = doc["protocol"].GetString();
			 }
			 if(operation == "d_calloc"){
				 int status;
				 char*address;
				 if (doc.HasMember("d_status")){
					 if (doc["d_status"].IsInt())
						 status = doc["d_status"].GetInt();
				 }
				 if (doc.HasMember("address")){
					 if(doc["address"].IsString()){
						 address = (char*)doc["address"].GetString();
						 cout << address << endl;
					 }
				 }
				 if (status = 0)
					 return address;

			 }
			 else if (operation == "d_get"){
				 int status;
				 char* data;
				 if (doc.HasMember("d_status")){
					 if (doc["d_status"].IsInt())
						 status = doc["d_status"].GetInt();
				 }
				 if (doc.HasMember("pDato")){
					 if (doc["pDato"].IsString()){
						 data = (char*)doc["pDato"].GetString();
					 }
				 }
				 if (status = 0)
					 return data;
			 }
			 else if (operation == "d_free"){
				 int status;
				 if (doc.HasMember("d_status")){
					 if (doc["d_status"].IsInt()){
						 status = doc["d_status"].GetInt();
					 }
				 }
			 }
			 else if (operation == "d_set"){
				 int status;
				 if (doc.HasMember("d_status")){
					 if (doc["d_status"].IsInt()){
						 status = doc["d_status"].GetInt();
					 }
				 }
			 }
		 }
	 }
	 return "NULL";

}**/
 void dHeap::dStatus(){
	 StringBuffer message;
	 Writer<StringBuffer> writer(message);
	 writer.StartObject();
	 writer.String("protocol");
	 writer.String("d_status");
	 writer.EndObject();
 }
dHeap::~dHeap()
{
	instanceFlag = false;
}
