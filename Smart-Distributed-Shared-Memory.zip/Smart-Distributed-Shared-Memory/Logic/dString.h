/*
 * dString.h
 *
 *  Created on: Oct 6, 2015
 *      Author: jairo-mm
 */

#ifndef LOGIC_DSTRING_H_
#define LOGIC_DSTRING_H_

#include "dObject.h"
#include <iostream>
#include "dpointersizetype.h"
#include <stddef.h>
#include <pthread.h>
#include <string.h>

using namespace std;

class dString: public dObject {
public:
	dString();
	virtual ~dString();
	/**
	 * @brief
	 * @param pstring
	 * @return
	 */
	void operator=(const dString& pstring);

	/**
	 * @brief
	 * @param pstring
	 * @return
	 */
	void operator=(const char* pstring);

	/**
	 * @brief
	 * @param pstring
	 * @return
	 */
	bool operator == (const dString& pint);

	/**
	 * @brief
	 * @param pstring
	 * @return
	*/
	bool operator == (const char* pstring);

	/**
	 * @brief
	 * @param
	 */
	static void* operator new(size_t );

	void* operator new[](size_t);

	/**
	 * @brief
	 * @return
	 */
	char* getData()const{
		//dInt* tmp = (dInt*)pointer->dPointer_getData_fromHeap();
		//return tmp->getData();
		return _data;
	}

	/**
	 * @brief
	 * @param pdata
	 */
	void setData(char* pdata){
		this->_data = pdata;
	}

	/**
	 *
	 */
	dString& operator[](int index);

private:
	char* _data = ""; /** dato del objeto */
	static d_pointer_size_type* pointer;
	void setDataWithPointer(char* pdata);
};

#endif /* LOGIC_DSTRING_H_ */
