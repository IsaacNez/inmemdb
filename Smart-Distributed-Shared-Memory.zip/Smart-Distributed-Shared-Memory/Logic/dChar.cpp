/*
 * dChar.cpp
 *
 *  Created on: Sep 15, 2015
 *      Author: jairo-mm
 */

#include "dChar.h"
#include <new>
/**
 * @brief
 */
dChar::dChar() {
	// TODO Auto-generated constructor stub
	_data = 0;

}

/**
 * @brief
 */
dChar::~dChar() {
	// TODO Auto-generated destructor stub
}


dChar& dChar::operator =(const dChar& pchar)
{
	pthread_mutex_lock(&this->mutex);
	setData(pchar.getData());
	pthread_mutex_unlock(&this->mutex);
	return *this;
}

/**
 * @brief
 * @param pchar
 * @return
 */
dChar& dChar::operator =(const char pchar)
{
	pthread_mutex_lock(&mutex);
	setData(pchar);
	pthread_mutex_unlock(&mutex);
	return *this;
}

/**
 * @brief
 * @param size
 */
void* dChar::operator new(size_t size)
{

	//TODO something about the memory in the SDSMMN

	return ::operator new(size);
}
