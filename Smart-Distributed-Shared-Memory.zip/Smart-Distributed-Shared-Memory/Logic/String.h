/*
 * String.h
 *
 *  Created on: Sep 15, 2015
 *      Author: jairo-mm
 */

#ifndef LOGIC_STRING_H_
#define LOGIC_STRING_H_

#include "dObject.h"
#include <string.h>
#include <stddef.h>
#include <pthread.h>

using namespace std;

class String: public dObject {

public:
	String();

	virtual ~String();

	/**
	 *
	 * @overload se sobrecarga el operador =
	 * @param pstring
	 * @return
	 */
	String& operator=(const String& pstring);

	/**
	 *
	 * * @overload se sobrecarga el operador =
	 * @param pstring
	 * @return
	 */
	String& operator=(char* pstring);

	/**
	 *
	 * * @overload se sobrecarga el operador =
	 * @param
	 */
	static void* operator new(size_t);

	/**
	 * Retorna el dato
	 * @return _data
	 */
	char* getData()const{
		//TODO usar otro metodo para hacer la operación de seteo de data
		return _data;
	}
	/**
	 * @brief Setea el dato
	 * @param pdata
	 */
	void setData(char* pdata){
		_data = pdata;
	}

private:
	char* _data; /** dato del tipo int, como el string no es un tipo de dato, se simula con un char**/
};


#endif /* LOGIC_STRING_H_ */
