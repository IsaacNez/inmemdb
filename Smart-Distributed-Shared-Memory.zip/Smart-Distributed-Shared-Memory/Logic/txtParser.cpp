/*
 * txtParcer.cpp
 *
 *  Created on: 27 de set. de 2015
 *      Author: jeja
 */

#include "txtParser.h"

/**
 * Constructor method of txtParser
 * @param pFile
 */
txtParser::txtParser(string pFile) {
	_File = pFile;
	_WordList = new LinkedList<string>();
	_Line = "";
	start();
}

/**
 * Method start the parser process
 */
void txtParser::start(){
	ifstream reader("/home/isaac/Escritorio/txtparsertest.txt");
	if(reader.is_open()){
		while(getline(reader,_Line)){
			divideWords();
		}
		reader.close();
		//_WordList->showList();
	}else{
		cout << "file is not open" << endl;
	}
}

/**
 * Method get the WordList
 * @return LinkedList<string>
 */
LinkedList<string>* txtParser::_getWordList(){
	return _WordList;
}

/**
 * Method divide in words, when the string has " ';),*:(!#$%^&_-=+|{}[]/.<>…�~		" one of this strings
 */
void txtParser::divideWords(){
	size_t position = 0;
	string word;
	while ((position = _Line.find_first_of(" ';),*:(!#$%^&_-=+|{}[]/.<>…�~		")) != std::string::npos) {
	    word = _Line.substr(0, position);
	    //cout << word << endl;
	    _WordList->insertData(word);
	    _Line.erase(0, position + 1);
	}
	//cout << _Line << endl;
	_WordList->insertData(_Line);
}

/**
 * Destructor method of txtParser
 */
txtParser::~txtParser() {
	// TODO Auto-generated destructor stub
}

