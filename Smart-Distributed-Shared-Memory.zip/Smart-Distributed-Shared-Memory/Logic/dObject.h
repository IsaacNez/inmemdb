/*
 * dObject.h
 *
 *  Created on: Sep 3, 2015
 *      Author: jairo-mm
 */

#ifndef LOGIC_DOBJECT_H_
#define LOGIC_DOBJECT_H_

/**
 * Esta clase hace la respectiva representacion de un objeto en la aplicacion
 * Cada objeto (tipo de dato sea tipo primitivo o no) que se quiera utilizar
 * debe heredar de esta clase para la encapsulación de objeto, de esta forma se
 * almacena en la memoria según este objeto
 */

#include<stdio.h>
#include<string.h>
#include<pthread.h>
#include<stdlib.h>
#include<unistd.h>


class dObject
{
public:
	dObject();
	virtual ~dObject();
	static void setObjectUsageFlag(bool pusageFlag);
	static bool getObjectUsageFlag();
	void setObjectType(char* pType);
	char* getObjectType();

private:
	char* _data_type; /** representa el tipo de dato */
	static bool _usageFlag; /** Bandera que identifica si el objeto está
								siendo usado (true) o no (false)*/
	static void* init(void*);

protected:
	pthread_mutex_t mutex;
};

#endif /* LOGIC_DOBJECT_H_ */
