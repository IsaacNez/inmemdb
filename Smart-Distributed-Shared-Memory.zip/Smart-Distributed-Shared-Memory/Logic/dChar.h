/*
 * dChar.h
 *
 *  Created on: Sep 15, 2015
 *      Author: jairo-mm
 */

#ifndef LOGIC_DCHAR_H_
#define LOGIC_DCHAR_H_

#include "dObject.h"
#include <stddef.h>
#include <pthread.h>

class dChar: public dObject {
public:
	dChar();
	virtual ~dChar();
	/**
	 * @brief
	 * @param pdchar
	 * @return
	 */
	dChar& operator=(const dChar& pdchar);

	/**
	 * @brief
	 * @param pchar
	 * @return
	 */
	dChar& operator=(const char pchar);

	/**
	 * @brief
	 * @param
	 */
	static void* operator new(size_t);

	/**
	 * @brief
	 * @return
	 */
	int getData()const{
		return _data;
	}

	/**
	 * @brief
	 * @param pdata
	 */
	void setData(char pdata){
		_data = pdata;
	}

private:
	char _data; /** dato del objeto */
};

#endif /* LOGIC_DCHAR_H_ */
