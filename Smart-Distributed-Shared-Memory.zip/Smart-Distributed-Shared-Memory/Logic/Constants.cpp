/*
 * Constants.cpp
 *
 *  Created on: Sep 30, 2015
 *      Author: jairo-mm
 */

#include "Constants.h"

bool Constants::DEBBUG_FLAG = true;
char* Constants::MAKING_A_COMPARISON_OF_OBJECTS = "Se está realizando una comparación de un objeto";
char* Constants::MAKING_AN_ASSIGNMENT_OF_OBJECTS = "Se está realizando una asignaciónde de un objeto";
char* Constants::MAKING_AN_EQUALIZATION_OF_OBJECTS = "Se está realizando una igualación de un objeto";
char* Constants::CREATING_A_NEW_OBJECT = "Se está creando un nuevo objeto";
char* Constants::MAKING_A_COMPARISON_OF_POINTERS = "Se está realizando una comparación de un pointer";
char* Constants::MAKING_AN_ASSIGNMENT_OF_POINTERS = "Se está realizando una asignaciónde de un pointer";
char* Constants::MAKING_AN_EQUALIZATION_OF_POINTERS = "Se está realizando una igualación de un pointer";
char* Constants::MEMORY_HAS_BEEN_RELEASE = "La memoria ha sido liberada";
char* Constants::WRONG_MEMORY_SPACE = "Es espacio de memoria no es el correcto, intente de nuevo";
char* Constants::SAVED_DATA = "El dato se ha guardado";
char* Constants::CLIENT = "Cliente";
char* Constants::IP = "IP";
char* Constants::PORT = "Port";
char* Constants::PROJECT = "project";
char* Constants::PROTOCOL = "protocol";
char* Constants::D_CALLOC = "d_calloc";
char* Constants::P_SIZE= "pSize";
char* Constants::ADDR = "addr";
char* Constants::D_FREE = "d_free";
char* Constants::D_STATUS = "d_status";
char* Constants::ADDRESS = "address";
char* Constants::TYPE = "type";
char* Constants::XML_ADDRESS = "XMLTest.xml";
char* Constants::DATA_SAVED = "El dato se ha guardado";
char* Constants::NOT_ACCESS_TO_MEMORY_SPACE = "No se pudo acceder al espacio de memoria";
char* Constants::MEMORY_FREED = "La memoria ha sido liberada";
char* Constants::INCORRECT_MEMORY_ACCESS = "Es espacio de memoria no es el correcto, intente de nuevo";
char* Constants::DATO = "dato";
char* Constants::DBOOL = "bool";
char* Constants::DCHAR = "char";
char* Constants::DDOUBLE = "double";
char* Constants::DFLOAT = "float";
char* Constants::DINT = "int";
char* Constants::DLONG = "long";
char* Constants::DSTRING = "string";
char* Constants::D_GET = "d_get";
char* Constants::D_SET = "d_set";
char* Constants::MAKING_GET_AND_SET_WITH_FROM_OBJECT = "se está realizando el get y el set data";
char* Constants::INT = "int";
char* Constants::MAKING_SET_FROM_POINTER_TO_HEAP = "Making a set data from pointer to heap";
char* Constants::MAKING_GET_FROM_POINTER_TO_HEAP = "Making a get data from pointer to heap";
char* Constants::SENDING_DATA_FROM_D_CALLOC = "Este es el mensaje de d_calloc";
char* Constants::SENDING_DATA_FROM_D_SET = "Este es el mensaje de set";
Constants::Constants() {
	// TODO Auto-generated constructor stub

}

Constants::~Constants() {
	// TODO Auto-generated destructor stub
}


