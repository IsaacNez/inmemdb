/*
 * DGarbageCollector.h
 *
 *  Created on: 9 de set. de 2015
 *      Author: jeja
 */

#ifndef LOGIC_DGARBAGECOLLECTOR_H_
#define LOGIC_DGARBAGECOLLECTOR_H_

#include <unistd.h>
#include "dHeap.h"
#include "dpointersizetype.h"
#include "../DataStructure/LinkedList.h"

class dGarbageCollector {
public:
	dGarbageCollector();
	void run();
	virtual ~dGarbageCollector();
private:
	int _Frequency;
	LinkedList<d_pointer_size_type*>* _TmpList;

};

#endif /* LOGIC_DGARBAGECOLLECTOR_H_ */
