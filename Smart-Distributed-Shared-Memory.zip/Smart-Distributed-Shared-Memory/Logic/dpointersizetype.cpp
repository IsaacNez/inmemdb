/*
 * Dpointersizetype.cpp
 *
 *  Created on: 7 de set. de 2015
 *      Author: jeja
 */

#include "dpointersizetype.h"
#include "dHeap.h"
#include "Constants.h"

long long int d_pointer_size_type::_Size = 0;

/**
 * @brief
 * Construction method of d_pointer_size_type
 */
d_pointer_size_type::d_pointer_size_type() {

}
/**
 *@brief
 * @param pID
 */
void d_pointer_size_type::setID(long long int pID){
	this->_ID = pID;
}

void d_pointer_size_type::setReference(int pIncrease){
	this->_Reference += pIncrease;
}

/**
 * @brief
 * @param pType
 */
void d_pointer_size_type::setType(char pType){
	this->_Type = pType;
}

/**
 * @brief
 * @param pSize
 */
void d_pointer_size_type::setSize(long long int pSize){
	this->_Size = pSize;
}

/**
 * @brief
 * @param pPointer
 */
void d_pointer_size_type::setPointer(char* pPointer){
	cout << "SETEANDO" << pPointer << endl;
	stringstream ss;
	ss << pPointer;
	ss >> _Pointer;
}

/**
 * @brief
 * @return
 */
long long int d_pointer_size_type::getID(){
	return this->_ID;
}

/**
 * @brief
 * @return
 */
char d_pointer_size_type::getType(){
	return this->_Type;
}

/**
 * @brief
 * @return
 */
long long int d_pointer_size_type::getSize(){
	return this->_Size;
}

/**
 * @param pLocation
 */
void d_pointer_size_type::setLocation(int pLocation){
	this->_Location = pLocation;
}


/**
 *
 * @return
 */
string d_pointer_size_type::getPointer(){
	return _Pointer;
}

/**
 * @return
 */
int d_pointer_size_type::getLocation(){
	return this->_Location;
}

int d_pointer_size_type::getReference(){
	return this->_Reference;
}
/**
 * @brief Overloading of operator (*), mark the use flag of an cell of memory
 */
dObject& d_pointer_size_type::operator *() {
	//dHeap* heap = dHeap::getInstance();
	dObject* a = new dObject();
	return *a;
}

/**
 * @brief Overloading of operator (=) if the parameter is a d_pointer_size_type,
 * copy the ID of the pDPointer
 */
d_pointer_size_type d_pointer_size_type::operator =(d_pointer_size_type pDPointer){
	if(Constants::DEBBUG_FLAG)
		std::cout << Constants::MAKING_AN_ASSIGNMENT_OF_POINTERS << std::endl;
	this->_ID = pDPointer._ID;
	this->_Pointer = pDPointer._Pointer;
	cout << "EStoy entrando aqui" << pDPointer.getPointer() << endl;
	this->_Reference = pDPointer._Reference;
	this->_Type = pDPointer._Type;
	return *this;
}

/**
 * @brief Overloading of operator (=) if the parameter is a dObject,
 * write in the heap and verify the size.
 */
d_pointer_size_type d_pointer_size_type::operator =(dObject pObject){
	if(Constants::DEBBUG_FLAG)
			std::cout << Constants::MAKING_AN_ASSIGNMENT_OF_POINTERS << std::endl;
	//dHeap* heap = dHeap::getInstance();
	//heap->dMalloc("pObject", "dObject");
	return *this;
}

/**
 * @brief Overloading of operator (==), compare the pDPointer with an other
 * pDPointer(Parameter).
 */
bool d_pointer_size_type::operator ==(d_pointer_size_type &pDPointer){
	if(Constants::DEBBUG_FLAG)
		std::cout << Constants::MAKING_AN_EQUALIZATION_OF_POINTERS << std::endl;
	if (this == &pDPointer){
		return false;
	}else{
		return false;

	}
}

/**
 * @brief Overloading of operator (++), increase to the next entry of the dHeap
 */
d_pointer_size_type& d_pointer_size_type::operator ++(){

	switch (this->_Type){
		case 56:

			this->_Pointer += 4;
			this->_Size -= 4;
			return *this;
		default:
			return *this;
	}
}

/**
 * @brief Overloading of operator (--), reduce to the next entry of the dHeap
 */
d_pointer_size_type& d_pointer_size_type::operator --(){

	switch (this->_Type){
			case 56:

				break;
		}
	return *this;
}

/**
 * @brief
 */
void d_pointer_size_type::print(){

}

/**
 * @brief Destruction method of d_pointer_size_type
 */
d_pointer_size_type::~d_pointer_size_type() {
	// TODO Auto-generated destructor stub
	//dHeap::getInstance()->dFree(this);
}

void d_pointer_size_type::dPointer_setData_ToHeap(void* pdata)
{
	if(Constants::DEBBUG_FLAG)
		cout << Constants::MAKING_SET_FROM_POINTER_TO_HEAP << endl;
	dHeap::getInstance()->dSet(this, (char*)pdata);
}

void* d_pointer_size_type::dPointer_getData_fromHeap()
{
	if(Constants::DEBBUG_FLAG)
		cout << Constants::MAKING_GET_FROM_POINTER_TO_HEAP << endl;
	return (void*)dHeap::getInstance()->dGet(this);
}
