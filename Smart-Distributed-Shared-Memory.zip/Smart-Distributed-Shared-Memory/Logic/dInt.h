/*
 * dInt.h
 *
 *  Created on: Sep 3, 2015
 *      Author: jairo-mm
 */

#ifndef LOGIC_DINT_H_
#define LOGIC_DINT_H_

#include "dObject.h"
#include "dpointersizetype.h"
#include <stddef.h>
#include <pthread.h>



class dInt : public dObject
{
public:
	dInt();
	virtual ~dInt();

	/**
	 * @brief
	 * @param pint
	 * @return
	 */
	void operator=(const dInt& pint);

	/**
	 * @brief
	 * @param pint
	 * @return
	 */
	void operator=(const int pint);

	/**
	 * @brief
	 * @param pint
	 * @return
	 */
	bool operator == (const dInt& pint);

	/**
	 * @brief
	 * @param pint
	 * @return
	*/
	bool operator == (const int pint);

	/**
	 * @brief
	 * @param
	 */
	static void* operator new(size_t );

	/**
	 * @brief
	 * @return
	 */
	int getData()const{
		//dInt* tmp = (dInt*)pointer->dPointer_getData_fromHeap();
		//return tmp->getData();
		return _data;
	}

	/**
	 * @brief
	 * @param pdata
	 */
	void setData(int pdata){
		_data = pdata;
	}

	/**
	 *
	 */
	dInt& operator[](int index);

private:
	int _data; /** dato del objeto */
	static d_pointer_size_type* pointer;
	void setDataWithPointer(int pdata);
};

#endif /* LOGIC_DINT_H_ */
