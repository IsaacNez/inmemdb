/*
 * dFloat.h
 *
 *  Created on: Sep 15, 2015
 *      Author: jairo-mm
 */

#ifndef LOGIC_DFLOAT_H_
#define LOGIC_DFLOAT_H_

#include "dObject.h"
#include <stddef.h>
#include <pthread.h>

class dFloat : public dObject {
public:
	dFloat();
	virtual ~dFloat();

	/**
	 * @brief
	 * @param pfloat
	 * @return
	 */
	dFloat& operator=(const dFloat& pfloat);
	/**
	 * @brief
	 * @param pfloat
	 * @return
	 */
	dFloat& operator=(const float pfloat);

	/**
	 * @brief
	 * @return
	 */
	float getData() const {return _data;}

	/**
	 * @brief
	 * @param pfloat
	 */
	void setData(float pfloat) { _data = pfloat;}

	/**
	 * @brief
	 * @param
	 */
	static void* operator new(size_t);

private:
	float _data; /** dato del objeto */
};

#endif /* LOGIC_DFLOAT_H_ */
