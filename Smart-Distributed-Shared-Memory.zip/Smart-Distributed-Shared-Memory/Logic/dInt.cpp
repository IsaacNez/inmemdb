/*
 * dInt.cpp
 *
 *  Created on: Sep 3, 2015
 *      Author: jairo-mm
 */

#include "dInt.h"
#include "dHeap.h"
#include "Constants.h"
#include <iostream>
#include <stdlib.h>
#include <new>

d_pointer_size_type* dInt::pointer = 0;

/**
 * @brief
 */
dInt::dInt() {
	_data = 0;
	if(Constants::DEBBUG_FLAG)
		std::cout << "dInt  "<< Constants::CREATING_A_NEW_OBJECT << std::endl;
	pointer->dPointer_setData_ToHeap((void*)this);

}

/**
 * @brief
 */
dInt::~dInt() {
	// TODO Auto-generated destructor stub
	dHeap::getInstance()->dFree(pointer);
}
/**
 * @brief
 * @param pint
 * @return
 */
void dInt::operator =(const dInt& pint)
{
	if(Constants::DEBBUG_FLAG)
		std::cout << Constants::MAKING_AN_EQUALIZATION_OF_OBJECTS << std::endl;
	setDataWithPointer(pint.getData());
	//setData(pint.getData());

}

/**
 * @brief
 * @param pint
 * @return
 */
void dInt::operator =(int pint)
{
	if(Constants::DEBBUG_FLAG)
		std::cout << Constants::MAKING_AN_ASSIGNMENT_OF_OBJECTS << std::endl;

	//pthread_mutex_lock(&this->mutex);
	setDataWithPointer(pint);
	//pthread_mutex_unlock(&this->mutex);
	//setData(pint);
}

/**
 * @brief
 * @param pint
 * @return
 */
bool dInt::operator ==(const dInt& pint)
{
	if(Constants::DEBBUG_FLAG)
		std::cout << Constants::MAKING_A_COMPARISON_OF_OBJECTS << std::endl;
	//pthread_mutex_lock(&this->mutex);
	if(this->_data == pint.getData())
		//pthread_mutex_unlock(&this->mutex);
		return true;
	//pthread_mutex_unlock(&this->mutex);
	return false;
}

/**
 * @brief
 * @param pint
 * @return
 */
bool dInt::operator ==(const int pint)
{
	if(Constants::DEBBUG_FLAG)
		std::cout << Constants::MAKING_A_COMPARISON_OF_OBJECTS << std::endl;
	//pthread_mutex_lock(&this->mutex);
	if(this->_data == pint)
		//pthread_mutex_unlock(&this->mutex);
		return true;
	return false;
}


/**
 * @brief
 * @param size
 * @return
 */
void* dInt::operator new(size_t size)
{
	pointer = (dHeap::getInstance()->dMalloc(size, Constants::INT));
	//TODO something about the memory in the SDSMMN
	return ::operator new(size);
}

dInt& dInt::operator [](int index)
{
	dInt* tmp = (dInt*)pointer->dPointer_getData_fromHeap();
	return *(tmp + index);
}

void dInt::setDataWithPointer(int pdata)
{
	cout << Constants::MAKING_GET_AND_SET_WITH_FROM_OBJECT << endl;
	dInt* tmp = (dInt*)pointer->dPointer_getData_fromHeap();
	tmp->setData(pdata);
	pointer->dPointer_setData_ToHeap((void*)tmp);
}
