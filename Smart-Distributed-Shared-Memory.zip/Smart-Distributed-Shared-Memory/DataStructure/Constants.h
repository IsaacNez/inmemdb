#ifndef DATASTRUCTURE_LINKEDLIST_H_
#define DATASTRUCTURE_LINKEDLIST_H_
#include <iostream>
#include <string>
#include <string.h>

using namespace std;

const string SEPARADOR = ";";
#endif
