/*
 * Cliente.h
 *
 *  Created on: 5 de oct. de 2015
 *      Author: gabo
 */

#ifndef DATACOMUNICATION_CLIENTE_H
#define DATACOMUNICATION_CLIENTE_H
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <string.h>
#include <string>
#include <stdio.h>
#include <iostream>
#include <pthread.h>
#include <vector>
#include <unistd.h>
#include <arpa/inet.h>
#include "rapidjson/stringbuffer.h"
#include "rapidjson/prettywriter.h"
#include "rapidjson/reader.h"
#include "rapidjson/writer.h"
#include "rapidjson/document.h"

using namespace std;
using namespace rapidjson;

class Cliente{

public:
    Cliente(int pPort, char* pIP);
    ~Cliente();
    char* Conectar(char* msj);
    void setMensaje(char* msn);

    static char* returned;
private:
    pthread_mutex_t flag;
    int _Port;
    char* _IP;
    int descriptor;
    sockaddr_in info;
    char* getMensaje();


};
#endif
