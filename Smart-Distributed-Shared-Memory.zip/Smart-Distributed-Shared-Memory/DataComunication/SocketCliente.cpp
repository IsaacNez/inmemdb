#include "SocketCliente.h"
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <string.h>
#include <string>
#include <iostream>
#include <pthread.h>
#include <vector>
#include <unistd.h>


SocketCliente::SocketCliente(int pPort, char* pIP)
{
	this->_IP = pIP;
	this->_Port = pPort;
}
char* SocketCliente::sendMessage(char *msj){
    string mensaje;
    char* memory;
    int status1;
    char* var = (char*)calloc(100,sizeof(char));
    if(connectClient()){
    	char* message = msj;
    	setMensaje(message);
   		char buffer[100] = {0};
   		memset(buffer, 0, 100);
   		int bytes = recv(descriptor,buffer,100,0);
   		mensaje.append(buffer,bytes);
   		cout<<"mensaje recibido " << "de" << (char*)(mensaje.c_str()) <<endl;
   		var = (char*)mensaje.c_str();
   		Document doc;
   		doc.ParseInsitu(var);
   		if (doc.IsObject()){
   				 if(doc.HasMember("protocol")){
   					 string operation;
   					 if (doc["protocol"].IsString()){
   						 operation = doc["protocol"].GetString();
   					 }
   					 if(operation == "d_calloc"){
   						 int status;
   						 char*address;
   						 if (doc.HasMember("d_status")){
   							 if (doc["d_status"].IsInt())
   								 status = doc["d_status"].GetInt();
   						 }
   						 if (doc.HasMember("address")){
   							 if(doc["address"].IsString()){
   								 address = (char*)doc["address"].GetString();
   							 }
   						 }
   						 if (status == 0)
   							 return address;

   					 }
   					 else if (operation == "d_get"){
   						 int status;
   						 char* data;
   						 if (doc.HasMember("d_status")){
   							 if (doc["d_status"].IsInt())
   								 status = doc["d_status"].GetInt();
   						 }
   						 if (doc.HasMember("pDato")){
   							 if (doc["pDato"].IsString()){
   								 data = (char*)doc["pDato"].GetString();
   							 }
   						 }
   						 if (status == 0){
   							 return data;}

   					 }
   					 else if (operation == "d_free"){
   						 int status;
   						 if (doc.HasMember("d_status")){
   							 if (doc["d_status"].IsInt()){
   								 status = doc["d_status"].GetInt();

   							 }
   						 }
   					 }
   					 else if (operation == "d_set"){
   						 int status;
   						 if (doc.HasMember("d_status")){
   							 if (doc["d_status"].IsInt()){
   								 status = doc["d_status"].GetInt();

   							 }
   						 }
   					 }
   				 }
   			 }

   	}
    return "1";



}

bool SocketCliente::connectClient()
{
    descriptor = socket(AF_INET,SOCK_STREAM,0);
    if(descriptor < 0)
        return false;
    info.sin_family = AF_INET;
    info.sin_addr.s_addr = inet_addr(this->_IP);
    info.sin_port = ntohs(this->_Port);
    memset(&info.sin_zero,0,sizeof(info.sin_zero));

    if((connect(descriptor,(sockaddr*)&info,(socklen_t)sizeof(info))) < 0){
     return false;}
    else
    	return true;
}


void * SocketCliente::controlador(void * obj)

{
    int descrip;
   
    while (true) {
        string mensaje;
           cout<<"dentro del while"<<endl;
            char buffer[10] = {0};
           
            int bytes = recv(descrip,buffer,10,0);
            cout<<bytes<<endl;
            mensaje.append(buffer,bytes);
            cout<<mensaje<<endl;
            sleep(3);
            
            if(bytes <= 0)
            {
               
                close(descrip);
                pthread_exit(NULL);
                break;
            }
    }
    close(descrip);
    pthread_exit(NULL);
}


void SocketCliente::setMensaje(char *msn)
{
   // char *mensaje = "GET / HTTP/1.1\r\nHost: www.google.com\r\nConnection: keep-alive\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\nUser-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.94 Safari/537.36\r\nX-Client-Data: CIm2yQEIorbJAQiptskBCLiIygEI3pbKAQ==\r\nAccept-Encoding: gzip,deflate,sdch\r\nAccept-Language: es-419,es;q=0.8,en;q=0.6\r\n\n";

   send(descriptor,msn,strlen(msn),0);
}
