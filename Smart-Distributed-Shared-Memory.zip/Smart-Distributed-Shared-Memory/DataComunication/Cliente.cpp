/*
 * Cliente.cpp
 *
 *  Created on: 5 de oct. de 2015
 *      Author: gabo
 */

#include "Cliente.h"

char* Cliente::returned="";

Cliente::Cliente(int pPort, char* pIP) {
	this->_IP = pIP;
	this->_Port = pPort;
	// TODO Auto-generated constructor stub

}

Cliente::~Cliente() {
	// TODO Auto-generated destructor stub
}

char* Cliente::Conectar(char* msj)
{
    descriptor = socket(AF_INET,SOCK_STREAM,0);
    if(descriptor < 0)
    {
        cout << "Error al crear el socket" << endl;
        return false;
    }
    info.sin_family = AF_INET;
    info.sin_addr.s_addr = inet_addr(this->_IP);
    info.sin_port = htons(this->_Port);
    memset(&info.sin_zero,0,sizeof(info.sin_zero));

    if((::connect(descriptor,(sockaddr*)&info,(socklen_t)sizeof(info))) < 0)
    {
        cout << "Error al conectar"<<endl;
        return "noMESAGE";
    }
    else{
		setMensaje(msj);
		char* v = getMensaje();
		return v;
    }

}

char* Cliente::getMensaje()
{
    int pDescriptor = descriptor;
    string mensaje;
    char buffer[256] = {0};
	int bytes = recv(pDescriptor,buffer,256,0);
	mensaje.append(buffer,bytes);
	char* h = (char*)mensaje.c_str();
	if (h == NULL)
		return "NULL";
	Document doc;
	//cout << "EL MENSAJE ES EL SIGUIENTE: " << h << endl;
	doc.ParseInsitu(h);
	//cout << "ERROR DE PARSEO " << doc.HasParseError() << endl;
	if (doc.IsObject()){
		if(doc.HasMember("protocol")){
			string operation;
			if (doc["protocol"].IsString()){
				operation = doc["protocol"].GetString();
			}
			if(operation == "d_calloc"){
				int status;
				char*address;
				if (doc.HasMember("d_status")){
					if (doc["d_status"].IsInt())
						status = doc["d_status"].GetInt();
				}
				if (doc.HasMember("address")){
					if(doc["address"].IsString()){
						address = (char*)doc["address"].GetString();
						cout <<"ADDRESS" << address << endl;
					}
				}
				if (status == 0)
					return address;
			}
			else if (operation == "d_get"){
				int status;
				char* data;
				if (doc.HasMember("d_status")){
					if (doc["d_status"].IsInt())
						status = doc["d_status"].GetInt();
				}
				if (doc.HasMember("bytestream")){
					if (doc["bytestream"].IsString()){
						data = (char*)doc["bytestream"].GetString();
					}
				}
				if (status == 0)
					return data;
			}
			else if (operation == "d_free"){
				int status;
				if (doc.HasMember("d_status")){
					if (doc["d_status"].IsInt()){
						status = doc["d_status"].GetInt();
					}
				}
			}
			else if (operation == "d_set"){
				int status;
				if (doc.HasMember("d_status")){
					if (doc["d_status"].IsInt()){
						status = doc["d_status"].GetInt();
					}
				}
			}
		}

	}
	fflush(stdout);
	return "NO SE PUDO ENTENDER EL JSON";
    close(pDescriptor);
}


void Cliente::setMensaje(char* msn)
{
    cout <<"Enviados" << send(descriptor,msn,strlen(msn),0) << endl;
}

