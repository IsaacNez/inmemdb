/*
 * SocketConstants.cpp
 *
 *  Created on: Aug 27, 2015
 *      Author: jairo-mm
 */

#include "SocketConstants.h"

SocketConstants::SocketConstants() {
	// TODO Auto-generated constructor stub

}

SocketConstants::~SocketConstants() {
	// TODO Auto-generated destructor stub
}

