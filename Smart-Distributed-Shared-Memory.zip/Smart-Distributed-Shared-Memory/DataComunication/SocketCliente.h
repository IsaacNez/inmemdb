#ifndef SOCKETCLIENTE_H
#define SOCKETCLIENTE_H
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <string.h>
#include <string>
#include <iostream>
#include <pthread.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "rapidjson/stringbuffer.h"
#include "rapidjson/prettywriter.h"
#include "rapidjson/reader.h"
#include "rapidjson/writer.h"
#include "rapidjson/document.h"

using namespace std;
using namespace rapidjson;

struct dataSocket{
    int descriptor;
    sockaddr_in info;
};

class SocketCliente{
public:
    SocketCliente(int pPort, char* pIP);
    bool connectClient();
    void setMensaje(char *msn);
    static void * controlador(void *obj);
    char* sendMessage(char *msj);
private:
    pthread_mutex_t lock;
    int descriptor;
    int _Port;
    char* _IP;
    sockaddr_in info;
    
};

#endif // SOCKETCLIENTE_H
