//============================================================================
// Name        : Smart.cpp
// Author      : jairo-mm
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "Logic/dHeap.h"
#include "DataComunication/SocketCliente.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/prettywriter.h"
#include "rapidjson/reader.h"
#include "rapidjson/writer.h"
#include "rapidjson/document.h"
#include "Logic/dString.h"
#include "Logic/dInt.h"
#include "Logic/txtParser.h"
using namespace std;



using namespace rapidjson;

int main() {

		txtParser* parser = new txtParser("hola");

		parser->_getWordList()->showList();
        for (int i=0;i<parser->_getWordList()->getLen();i++){
        	dString* num1 = new dString();
        	* num1  = (char*)(parser->_getWordList()->getDatabyIndex(i)).c_str();
        }



//	StringBuffer s;
//	Writer<StringBuffer> writer(s);
//	writer.StartObject();
//	writer.String("protocol");
//	writer.String("d_calloc");
//	writer.String("pSize");
//	writer.Int(sizeof(dInt));
//	writer.EndObject();
//	cout << cliente->sendMessage(s.GetString())<< endl;
	return 0;
}
